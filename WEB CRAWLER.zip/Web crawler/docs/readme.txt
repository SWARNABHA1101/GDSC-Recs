Drawing created with https://www.draw.io
