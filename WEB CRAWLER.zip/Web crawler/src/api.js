'use strict';

var searchCrawler = require('./searchCrawler.js');
var errorHandling = require('./expressErrorHandling.js');
let SiteModel = require('./models/SiteModel.js');
let crawler = require('./crawler.js');
let parser = require('./parser.js');

var regExpEscape = function (s) {
  return s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
};

function init(app) {
  // Site List
  app.get('/api/sites', async function (req, res) {
    await SiteModel.find({}, function (err, sites) {
      if (err) {
        errorHandling.renderError(res, err);
      } else {
        res.json(sites);
      }
    });
  });

  // Site Get
  app.get('/api/sites/:siteName', async function (req, res) {
    var siteName = req.param('siteName');
    console.log('READ', siteName);
    await SiteModel.findOne({ name: siteName }, function (err, site) {
      if (err) {
        errorHandling.renderError(res, err);
      } else {
        res.json(site);
      }
    });
  });

  // Jobs List
  app.get('/api/jobs', function (req, res) {
    searchCrawler
      .getJobs()
      .then(function (result) {
        res.json(result);
      })
      .fail(function (error) {
        errorHandling.renderError(res, error);
      });
  });

  // Jobs load
  app.post('/api/jobs/load', function (req, res) {
    searchCrawler
      .loadJobs()
      .then(function (result) {
        res.json(result);
      })
      .fail(function (error) {
        errorHandling.renderError(res, error);
      });
  });

  // Jobs unload
  app.post('/api/jobs/unload', function (req, res) {
    searchCrawler
      .unloadJobs()
      .then(function (result) {
        res.json(result);
      })
      .fail(function (error) {
        errorHandling.renderError(res, error);
      });
  });

  // Site Get Pages
  app.get('/api/sites/:siteName/pages', async function (req, res) {
    var siteName = req.param('siteName');
    console.log('GET PAGES', siteName);
    await SiteModel.findOne({ name: siteName }, async function (err, site) {
      if (err) {
        errorHandling.renderError(res, err);
      } else {
        result = await site.appGetPages();
        console.log('RES', result);
        res.json(result);
      }
    });
  });

  // Site Create
  app.post('/api/sites', async function (req, res) {
    let site = req.body;
    if (!site.config) {
      site.config = { crawlingCron: null };
    }
    if (!site.config.contentSelector) {
      site.config.contentSelector = 'body';
    }
    if (!site.config.urlPattern && site.url) {
      site.config.urlPattern = '^' + regExpEscape(site.url);
    }
    console.log('CREATE', site);
    await SiteModel.create(site, function (err, site) {
      if (err) {
        errorHandling.renderError(res, err);
      } else {
        res.json(undefined);
      }
    });
  });

  // Site Update Config
  app.post('/api/sites/:siteName/update-config', async function (req, res) {
    var newConfig = req.body;
    var siteName = req.param('siteName');
    console.log('UPDATE CONFIG', siteName, newConfig);
    await SiteModel.findOneAndUpdate(
      { name: siteName },
      { $set: { config: newConfig } },
      { new: true },
      function (err, site) {
        if (err) {
          errorHandling.renderError(res, err);
        } else {
          res.json(site);
        }
      }
    );
  });

  // Site Delete
  app.delete('/api/sites/:siteName', async function (req, res) {
    var siteName = req.param('siteName');
    console.log('DELETE', siteName);
    await SiteModel.deleteOne({ name: siteName }, function (err, site) {
      if (err) {
        errorHandling.renderError(res, err);
      } else {
        res.json(undefined);
      }
    });
  });

  // Site Crawl
  app.post('/api/sites/:siteName/crawl', function (req, res) {
    var siteName = req.param('siteName');
    let siteToCrawl;
    console.log('CRAWL', siteName);
    SiteModel.findOne({ name: siteName })
      .then(async function (site) {
        siteToCrawl = site;
        await siteToCrawl.appDeletePages();
      })
      .then(function () {
        console.log('CRAWLING PAGES NOW...');
        crawler.crawl(
          siteToCrawl.url,
          siteToCrawl.config,
          function (url, htmlContent) {
            let page = parser.parse(htmlContent, siteToCrawl.config);
            page.url = url;
            page.siteId = siteToCrawl._id;
            siteToCrawl.appInsertPage(page);
          },
          async function () {
            siteToCrawl.status = 'crawling';
            const res = await siteToCrawl.save();
            console.log('CRAWLING UPDATE');
          },
          async function () {
            siteToCrawl.status = 'ready';
            siteToCrawl.lastCrawled = Date.now();
            const res = await siteToCrawl.save();
            console.log('CRAWLING DONE');
          }
        );
        return true;
      })
      .then(function () {
        res.send('OK: Crawling in progress...');
      })
      .catch(function (err) {
        errorHandling.renderError(res, err);
      });
  });

  // Site Register Page
  app.post('/api/sites/:siteName/register-page', function (req, res) {
    var url = req.body.url;
    var siteName = req.param('siteName');

    searchCrawler
      .registerPage(siteName, url)
      .then(function (result) {
        res.json(result);
      })
      .fail(function (error) {
        errorHandling.renderError(res, error);
      });
  });

  // Site Remove Pages
  app['delete']('/api/sites/:siteName/remove-pages', function (req, res) {
    var siteName = req.param('siteName');

    searchCrawler
      .removePages(siteName)
      .then(function (result) {
        res.json(result);
      })
      .fail(function (error) {
        errorHandling.renderError(res, error);
      });
  });

  // Site page count
  app.get('/api/sites/:siteName/page-count', async function (req, res) {
    var siteName = req.param('siteName');
    let result = 0;
    console.log('PAGE COUNT', siteName, result);
    await SiteModel.findOne({ name: siteName }, async function (err, site) {
      if (err) {
        errorHandling.renderError(res, err);
      } else {
        result = await site.appCountPages();
        res.json({ value: result });
      }
    });
  });

  // Search
  app.get('/api/sites/:siteName/search', function (req, res) {
    var siteName = req.param('siteName');
    var queryExpression = req.query.q || req.query.query;
    var limit = 10 || parseInt(req.query.l || req.query.limit);
    console.log('SEARCH', siteName, queryExpression, limit);

    SiteModel.findOne({ name: siteName }).then(async function (site) {
      console.log("SEARCHING...")
      const result = await site.appSearchPages(queryExpression, limit);
      console.log("SEARCH DONE", result)
      res.json(result);
    }).catch(function (err) {
      errorHandling.renderError(res, err);
    });
  });
}

exports.init = init;
