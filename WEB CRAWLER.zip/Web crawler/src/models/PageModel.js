let mongoose = require('mongoose');

const Schema = mongoose.Schema;

const PageModel = new Schema({
  siteId: {
    type: String,
    required: true,
  },
  url: {
    type: String,
    required: true,
  },
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  body: {
    type: String,
    required: true,
  },
  keywords: [String],
});

PageModel.index({ siteId: 1, url: 1 }, { name: 'key', unique: true });
PageModel.index({ siteId: 1, '$**': 'text' }, { name: 'searchIndex' });

module.exports =
  mongoose.models.PageModel || mongoose.model('PageModel', PageModel, 'pages');
