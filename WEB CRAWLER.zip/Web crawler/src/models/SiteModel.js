let mongoose = require('mongoose');
let PageModel = require('./PageModel.js');

const Schema = mongoose.Schema;

const SiteModel = new Schema({
  name: {
    type: String,
    required: true,
    match: /^[\w_\.-]{3,20}$/,
  },
  url: {
    type: String,
    required: true,
    match: /^http.{3,}/,
  },
  status: {
    type: String,
    required: true,
    enum: ['ready', 'crawling'],
    default: 'ready',
  },
  lastCrawled: {
    type: Date,
    required: false,
  },
  config: {
    contentSelector: {
      type: String,
      required: true,
    },
    urlPattern: {
      type: String,
      required: true,
    },
    crawlingCron: {
      type: String,
      required: false,
    },
  },
});

SiteModel.index({ name: 1 }, { name: 'key', unique: true });

SiteModel.methods.appCountPages = async function () {
  return await PageModel.count({ siteId: this._id });
};

SiteModel.methods.appGetPages = async function () {
  return await PageModel.where({ siteId: this._id }).find({});
};

SiteModel.methods.appInsertPage = async function (page) {
  if (!page.keywords) {
    page.keywords = [];
  }
  page.keywords.push('*');
  PageModel.create(page, function (err, page) {
    if (err) {
      console.log(err);
    } else {
      console.log('page inserted', page.url);
    }
  });
};

SiteModel.methods.appDeletePage = async function (pageUrl) {
  console.log('delete page', pageUrl);
  const res = await PageModel.remove({ siteId: this._id, url: pageUrl });
  return res.deletedCount;
};

SiteModel.methods.appDeletePages = async function () {
  console.log('DELETING ALL PAGES...');
  const res = PageModel.where({ siteId: this._id }).remove(
    {},
    function (err, removed) {
      if (err) {
        console.log(err);
      }
      console.log('removed', removed);
      return removed;
    }
  );
  console.log('DELETED ALL PAGES', res);
  return res.deletedCount;
};

SiteModel.methods.appSearchPages = async function (expression, limit) {
  if (!limit || limit < 0 || limit > 100 || isNaN(limit)) {
    limit = 10;
  }

  let siteId = this._id;
  var criteria = {
    siteId: siteId,
    $text: { $search: expression },
  };
  var sort = { score: { $meta: 'textScore' } };
  var projection = {
    url: 1,
    title: 1,
    description: 1,
    keywords: 1,
    score: { $meta: 'textScore' },
  };

  return await PageModel.where(criteria)
    .sort(sort)
    .select(projection)
    .limit(limit);
};

module.exports =
  mongoose.models.SiteModel || mongoose.model('SiteModel', SiteModel, 'sites');
